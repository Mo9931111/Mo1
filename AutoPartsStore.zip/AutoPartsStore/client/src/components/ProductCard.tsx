import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart } from "lucide-react";
import { useState } from "react";

interface ProductCardProps {
  id: string;
  name: string;
  price: number;
  oldPrice?: number;
  image: string;
  inStock: boolean;
  isNew?: boolean;
  onSale?: boolean;
  onAddToCart?: (id: string) => void;
}

export default function ProductCard({
  id,
  name,
  price,
  oldPrice,
  image,
  inStock,
  isNew,
  onSale,
  onAddToCart,
}: ProductCardProps) {
  const [isAdding, setIsAdding] = useState(false);

  const handleAddToCart = () => {
    setIsAdding(true);
    onAddToCart?.(id);
    console.log('Added to cart:', id);
    setTimeout(() => setIsAdding(false), 500);
  };

  return (
    <Card className="overflow-hidden hover-elevate transition-all group" data-testid={`card-product-${id}`}>
      <div className="relative aspect-[4/3] overflow-hidden bg-muted">
        <img
          src={image}
          alt={name}
          className="w-full h-full object-cover transition-transform group-hover:scale-105"
          loading="lazy"
        />
        {(isNew || onSale) && (
          <div className="absolute top-2 left-2 flex flex-col gap-2">
            {isNew && (
              <Badge className="bg-chart-3 text-white border-0" data-testid="badge-new">
                جديد
              </Badge>
            )}
            {onSale && (
              <Badge variant="destructive" data-testid="badge-sale">
                تخفيض
              </Badge>
            )}
          </div>
        )}
        {!inStock && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <Badge variant="secondary" className="text-base px-4 py-2">
              غير متوفر
            </Badge>
          </div>
        )}
      </div>

      <CardContent className="p-4">
        <h3 className="font-semibold text-base mb-2 line-clamp-2 min-h-[3rem]" data-testid={`text-product-name-${id}`}>
          {name}
        </h3>
        
        <div className="flex items-center gap-2 mb-2">
          <span className="text-2xl font-bold text-primary" data-testid={`text-price-${id}`}>
            {price} ريال
          </span>
          {oldPrice && (
            <span className="text-sm text-muted-foreground line-through" data-testid={`text-old-price-${id}`}>
              {oldPrice} ريال
            </span>
          )}
        </div>

        {inStock && (
          <div className="flex items-center gap-2 text-sm">
            <div className="w-2 h-2 rounded-full bg-chart-3" />
            <span className="text-muted-foreground">متوفر</span>
          </div>
        )}
      </CardContent>

      <CardFooter className="p-4 pt-0">
        <Button
          className="w-full gap-2"
          onClick={handleAddToCart}
          disabled={!inStock || isAdding}
          data-testid={`button-add-to-cart-${id}`}
        >
          <ShoppingCart className="w-4 h-4" />
          {isAdding ? 'جاري الإضافة...' : 'إضافة للسلة'}
        </Button>
      </CardFooter>
    </Card>
  );
}
