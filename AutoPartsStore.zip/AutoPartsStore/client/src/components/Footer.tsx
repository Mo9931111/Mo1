import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Phone, Mail, MapPin, Facebook, Instagram, Twitter } from "lucide-react";
import { SiVisa, SiMastercard } from "react-icons/si";

export default function Footer() {
  return (
    <footer className="bg-card border-t mt-20">
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="font-bold text-lg mb-4">عن المتجر</h3>
            <p className="text-sm text-muted-foreground mb-4">
              متجر متخصص في توفير قطع غيار السيارات الأصلية بأفضل الأسعار وأعلى جودة
            </p>
            <div className="flex gap-2">
              <Button variant="outline" size="icon" className="h-9 w-9" data-testid="link-facebook">
                <Facebook className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon" className="h-9 w-9" data-testid="link-instagram">
                <Instagram className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon" className="h-9 w-9" data-testid="link-twitter">
                <Twitter className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">روابط سريعة</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-about">من نحن</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-products">المنتجات</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-offers">العروض الخاصة</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-contact">اتصل بنا</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">خدمة العملاء</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-shipping">سياسة الشحن</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-returns">سياسة الإرجاع</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-warranty">الضمان</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-faq">الأسئلة الشائعة</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">تواصل معنا</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2 text-muted-foreground">
                <Phone className="h-4 w-4" />
                <span>+966 50 123 4567</span>
              </li>
              <li className="flex items-center gap-2 text-muted-foreground">
                <Mail className="h-4 w-4" />
                <span>info@autoparts.sa</span>
              </li>
              <li className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="h-4 w-4" />
                <span>الرياض، المملكة العربية السعودية</span>
              </li>
            </ul>
          </div>
        </div>

        <Separator className="mb-8" />

        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-sm text-muted-foreground text-center md:text-right">
            © 2025 متجر قطع غيار السيارات. جميع الحقوق محفوظة.
          </div>
          
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">طرق الدفع:</span>
            <div className="flex gap-2">
              <div className="w-10 h-7 bg-muted rounded flex items-center justify-center">
                <SiVisa className="h-5 w-5" />
              </div>
              <div className="w-10 h-7 bg-muted rounded flex items-center justify-center">
                <SiMastercard className="h-5 w-5" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
