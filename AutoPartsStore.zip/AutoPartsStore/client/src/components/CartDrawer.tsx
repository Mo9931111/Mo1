import { X, Minus, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity?: (id: string, quantity: number) => void;
  onRemoveItem?: (id: string) => void;
  onCheckout?: () => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
}: CartDrawerProps) {
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  if (!isOpen) return null;

  return (
    <>
      <div
        className="fixed inset-0 bg-black/50 z-50"
        onClick={onClose}
        data-testid="overlay-cart"
      />
      
      <div className="fixed left-0 top-0 bottom-0 w-full max-w-md bg-background z-50 shadow-xl flex flex-col" data-testid="drawer-cart">
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-2xl font-bold">سلة التسوق</h2>
          <Button variant="ghost" size="icon" onClick={onClose} data-testid="button-close-cart">
            <X className="h-5 w-5" />
          </Button>
        </div>

        {items.length === 0 ? (
          <div className="flex-1 flex items-center justify-center p-6">
            <div className="text-center">
              <p className="text-muted-foreground text-lg mb-4">سلة التسوق فارغة</p>
              <Button onClick={onClose} data-testid="button-continue-shopping">
                تصفح المنتجات
              </Button>
            </div>
          </div>
        ) : (
          <>
            <ScrollArea className="flex-1 p-6">
              <div className="space-y-4">
                {items.map((item) => (
                  <div key={item.id} className="flex gap-4" data-testid={`cart-item-${item.id}`}>
                    <div className="w-20 h-20 rounded-md overflow-hidden bg-muted flex-shrink-0">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-sm mb-1 line-clamp-2" data-testid={`text-cart-item-name-${item.id}`}>
                        {item.name}
                      </h3>
                      <p className="text-primary font-bold mb-2" data-testid={`text-cart-item-price-${item.id}`}>
                        {item.price} ريال
                      </p>
                      
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => {
                            onUpdateQuantity?.(item.id, Math.max(1, item.quantity - 1));
                            console.log('Decrease quantity:', item.id);
                          }}
                          data-testid={`button-decrease-${item.id}`}
                        >
                          <Minus className="h-3 w-3" />
                        </Button>
                        
                        <span className="w-8 text-center font-semibold" data-testid={`text-quantity-${item.id}`}>
                          {item.quantity}
                        </span>
                        
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => {
                            onUpdateQuantity?.(item.id, item.quantity + 1);
                            console.log('Increase quantity:', item.id);
                          }}
                          data-testid={`button-increase-${item.id}`}
                        >
                          <Plus className="h-3 w-3" />
                        </Button>
                        
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 mr-auto"
                          onClick={() => {
                            onRemoveItem?.(item.id);
                            console.log('Remove item:', item.id);
                          }}
                          data-testid={`button-remove-${item.id}`}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>

            <div className="border-t p-6 space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">المجموع الفرعي</span>
                  <span>{total} ريال</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">الشحن</span>
                  <span className="text-chart-3">مجاني</span>
                </div>
                <Separator />
                <div className="flex justify-between text-lg font-bold">
                  <span>الإجمالي</span>
                  <span className="text-primary" data-testid="text-cart-total">{total} ريال</span>
                </div>
              </div>

              <Button
                className="w-full"
                size="lg"
                onClick={() => {
                  onCheckout?.();
                  console.log('Checkout clicked');
                }}
                data-testid="button-checkout"
              >
                إتمام الطلب
              </Button>
            </div>
          </>
        )}
      </div>
    </>
  );
}
