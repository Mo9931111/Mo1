import { Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";

interface HeroProps {
  backgroundImage: string;
  onSearch?: (value: string) => void;
}

export default function Hero({ backgroundImage, onSearch }: HeroProps) {
  const [searchValue, setSearchValue] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch?.(searchValue);
    console.log('Hero search:', searchValue);
  };

  return (
    <div className="relative h-[500px] md:h-[600px] overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${backgroundImage})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-black/30" />
      
      <div className="relative h-full max-w-7xl mx-auto px-4 md:px-6 lg:px-8 flex flex-col items-center justify-center text-center">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4">
          قطع غيار أصلية لجميع أنواع السيارات
        </h1>
        <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl">
          نوفر لك أفضل قطع الغيار الأصلية بأسعار منافسة مع ضمان الجودة والتوصيل السريع
        </p>

        <form onSubmit={handleSearch} className="w-full max-w-2xl">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute right-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="search"
                placeholder="ابحث عن القطعة التي تحتاجها..."
                className="pr-12 h-12 md:h-14 text-base bg-white/95 backdrop-blur-sm border-0 focus-visible:ring-2"
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
                data-testid="input-hero-search"
              />
            </div>
            <Button
              type="submit"
              size="lg"
              className="h-12 md:h-14 px-6 md:px-8"
              data-testid="button-hero-search"
            >
              بحث
            </Button>
          </div>
        </form>

        <div className="mt-12 flex flex-wrap gap-4 justify-center">
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-md px-6 py-3 text-white">
            <div className="text-2xl font-bold">5000+</div>
            <div className="text-sm text-white/80">قطعة متوفرة</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-md px-6 py-3 text-white">
            <div className="text-2xl font-bold">24/7</div>
            <div className="text-sm text-white/80">دعم العملاء</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-md px-6 py-3 text-white">
            <div className="text-2xl font-bold">ضمان</div>
            <div className="text-sm text-white/80">على كل المنتجات</div>
          </div>
        </div>
      </div>
    </div>
  );
}
