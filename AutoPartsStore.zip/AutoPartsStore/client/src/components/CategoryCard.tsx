import { Card } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface CategoryCardProps {
  title: string;
  icon: LucideIcon;
  count: number;
  onClick?: () => void;
}

export default function CategoryCard({ title, icon: Icon, count, onClick }: CategoryCardProps) {
  return (
    <Card
      className="hover-elevate active-elevate-2 cursor-pointer transition-all p-6"
      onClick={() => {
        onClick?.();
        console.log('Category clicked:', title);
      }}
      data-testid={`card-category-${title}`}
    >
      <div className="flex flex-col items-center text-center gap-4">
        <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
          <Icon className="w-8 h-8 text-primary" />
        </div>
        <div>
          <h3 className="font-semibold text-lg mb-1">{title}</h3>
          <p className="text-sm text-muted-foreground">{count} منتج</p>
        </div>
      </div>
    </Card>
  );
}
