import ProductCard from '../ProductCard';
import brakeImage from '@assets/generated_images/Brake_pads_product_photo_327146ec.png';

export default function ProductCardExample() {
  return (
    <div className="p-4 max-w-sm">
      <ProductCard
        id="1"
        name="فحمات فرامل أمامية - تويوتا كامري"
        price={250}
        oldPrice={320}
        image={brakeImage}
        inStock={true}
        onSale={true}
        onAddToCart={(id) => console.log('Add to cart:', id)}
      />
    </div>
  );
}
