import CategoryCard from '../CategoryCard';
import { Wrench } from 'lucide-react';

export default function CategoryCardExample() {
  return (
    <div className="p-4">
      <CategoryCard
        title="قطع المحرك"
        icon={Wrench}
        count={350}
        onClick={() => console.log('Category clicked')}
      />
    </div>
  );
}
