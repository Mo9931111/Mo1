import Hero from '../Hero';
import heroImage from '@assets/generated_images/Auto_parts_warehouse_hero_a4664297.png';

export default function HeroExample() {
  return (
    <Hero
      backgroundImage={heroImage}
      onSearch={(value) => console.log('Search submitted:', value)}
    />
  );
}
