import CartDrawer from '../CartDrawer';
import brakeImage from '@assets/generated_images/Brake_pads_product_photo_327146ec.png';
import filterImage from '@assets/generated_images/Oil_filter_product_photo_0573d30e.png';
import { useState } from 'react';

export default function CartDrawerExample() {
  const [isOpen, setIsOpen] = useState(true);
  const [items, setItems] = useState([
    {
      id: '1',
      name: 'فحمات فرامل أمامية - تويوتا كامري',
      price: 250,
      quantity: 2,
      image: brakeImage,
    },
    {
      id: '2',
      name: 'فلتر زيت - هونداي النترا',
      price: 45,
      quantity: 1,
      image: filterImage,
    },
  ]);

  return (
    <CartDrawer
      isOpen={isOpen}
      onClose={() => setIsOpen(false)}
      items={items}
      onUpdateQuantity={(id, quantity) => {
        setItems(items.map(item => item.id === id ? { ...item, quantity } : item));
      }}
      onRemoveItem={(id) => {
        setItems(items.filter(item => item.id !== id));
      }}
      onCheckout={() => console.log('Checkout')}
    />
  );
}
