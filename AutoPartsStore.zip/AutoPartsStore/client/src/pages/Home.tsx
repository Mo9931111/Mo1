import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import CategoryCard from "@/components/CategoryCard";
import ProductCard from "@/components/ProductCard";
import CartDrawer from "@/components/CartDrawer";
import Footer from "@/components/Footer";
import CheckoutDialog from "@/components/CheckoutDialog";
import { Wrench, Zap, Droplet, Wind, Battery, Lightbulb } from "lucide-react";
import { Product } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

import heroImage from '@assets/generated_images/Auto_parts_warehouse_hero_a4664297.png';

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

export default function Home() {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const { toast } = useToast();

  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  const categories = [
    { title: "قطع المحرك", icon: Wrench, count: 350 },
    { title: "نظام الكهرباء", icon: Zap, count: 280 },
    { title: "نظام التبريد", icon: Droplet, count: 120 },
    { title: "الفلاتر", icon: Wind, count: 200 },
    { title: "البطاريات", icon: Battery, count: 95 },
    { title: "الإضاءة", icon: Lightbulb, count: 180 },
  ];

  const handleAddToCart = (productId: string) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    setCartItems(prevItems => {
      const existingItem = prevItems.find(item => item.id === productId);
      if (existingItem) {
        toast({
          title: "تمت الإضافة",
          description: "تم تحديث الكمية في السلة",
        });
        return prevItems.map(item =>
          item.id === productId
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      toast({
        title: "تمت الإضافة للسلة",
        description: product.name,
      });
      return [
        ...prevItems,
        {
          id: product.id,
          name: product.name,
          price: parseFloat(product.price),
          quantity: 1,
          image: product.image,
        },
      ];
    });
  };

  const handleUpdateQuantity = (id: string, quantity: number) => {
    setCartItems(prevItems =>
      prevItems.map(item =>
        item.id === id ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveItem = (id: string) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== id));
    toast({
      title: "تم الحذف",
      description: "تم حذف المنتج من السلة",
    });
  };

  const handleCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handleOrderComplete = () => {
    setCartItems([]);
    setIsCheckoutOpen(false);
    toast({
      title: "تم إرسال الطلب بنجاح",
      description: "سنتواصل معك قريباً لتأكيد الطلب",
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header
        cartItemsCount={cartItems.reduce((sum, item) => sum + item.quantity, 0)}
        onCartClick={() => setIsCartOpen(true)}
      />

      <main className="flex-1">
        <Hero backgroundImage={heroImage} />

        <section className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">تصفح حسب الفئة</h2>
            <p className="text-muted-foreground text-lg">
              اختر الفئة المناسبة للعثور على القطعة التي تحتاجها
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((category) => (
              <CategoryCard key={category.title} {...category} />
            ))}
          </div>
        </section>

        <section className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">الأكثر مبيعاً</h2>
            <p className="text-muted-foreground text-lg">
              قطع الغيار الأكثر طلباً من عملائنا
            </p>
          </div>

          {isLoading ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">جاري التحميل...</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
              {products.map((product) => (
                <ProductCard
                  key={product.id}
                  id={product.id}
                  name={product.name}
                  price={parseFloat(product.price)}
                  oldPrice={product.oldPrice ? parseFloat(product.oldPrice) : undefined}
                  image={product.image}
                  inStock={product.inStock}
                  isNew={product.isNew || false}
                  onSale={product.onSale || false}
                  onAddToCart={handleAddToCart}
                />
              ))}
            </div>
          )}
        </section>

        <section className="bg-card py-16 my-12">
          <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">لماذا تختارنا؟</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Wrench className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2">قطع أصلية مضمونة</h3>
                <p className="text-muted-foreground">
                  جميع منتجاتنا أصلية 100% مع ضمان الجودة والأداء
                </p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2">توصيل سريع</h3>
                <p className="text-muted-foreground">
                  خدمة التوصيل في نفس اليوم داخل المدينة
                </p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Battery className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2">دعم فني متخصص</h3>
                <p className="text-muted-foreground">
                  فريق دعم فني متاح على مدار الساعة لمساعدتك
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onCheckout={handleCheckout}
      />

      <CheckoutDialog
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cartItems={cartItems}
        onOrderComplete={handleOrderComplete}
      />
    </div>
  );
}
