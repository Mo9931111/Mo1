import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertOrderSchema } from "@shared/schema";
import path from "path";
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/products", async (_req, res) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  app.post("/api/orders", async (req, res) => {
    try {
      const validatedData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(validatedData);
      res.status(201).json(order);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to create order" });
      }
    }
  });

  app.get("/api/images/:filename", (_req, res) => {
    const imagesPath = path.join(__dirname, '../attached_assets/generated_images');
    const imageMap: Record<string, string> = {
      'brake-pads.png': 'Brake_pads_product_photo_327146ec.png',
      'oil-filter.png': 'Oil_filter_product_photo_0573d30e.png',
      'headlight.png': 'Headlight_assembly_product_photo_63b3e3ae.png',
      'battery.png': 'Car_battery_product_photo_57f63817.png',
      'air-filter.png': 'Air_filter_product_photo_1657bc75.png',
      'spark-plugs.png': 'Spark_plugs_product_photo_d900b615.png',
    };

    const requestedFile = _req.params.filename;
    const actualFile = imageMap[requestedFile];
    
    if (actualFile) {
      res.sendFile(path.join(imagesPath, actualFile));
    } else {
      res.status(404).send('Image not found');
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
