import { type Product, type InsertProduct, type Order, type InsertOrder } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  createOrder(order: InsertOrder): Promise<Order>;
  getOrders(): Promise<Order[]>;
}

export class MemStorage implements IStorage {
  private products: Map<string, Product>;
  private orders: Map<string, Order>;

  constructor() {
    this.products = new Map();
    this.orders = new Map();
    this.seedProducts();
  }

  private seedProducts() {
    const initialProducts: Omit<Product, 'id'>[] = [
      {
        name: "فحمات فرامل أمامية - تويوتا كامري 2018-2023",
        price: "250.00",
        oldPrice: "320.00",
        image: "/api/images/brake-pads.png",
        category: "فرامل",
        inStock: true,
        isNew: false,
        onSale: true,
      },
      {
        name: "فلتر زيت محرك - هونداي النترا",
        price: "45.00",
        oldPrice: null,
        image: "/api/images/oil-filter.png",
        category: "فلاتر",
        inStock: true,
        isNew: true,
        onSale: false,
      },
      {
        name: "مجموعة إضاءة أمامية LED - نيسان التيما",
        price: "1200.00",
        oldPrice: "1500.00",
        image: "/api/images/headlight.png",
        category: "إضاءة",
        inStock: true,
        isNew: false,
        onSale: true,
      },
      {
        name: "بطارية سيارة 70 أمبير - ACDelco",
        price: "380.00",
        oldPrice: null,
        image: "/api/images/battery.png",
        category: "بطاريات",
        inStock: true,
        isNew: false,
        onSale: false,
      },
      {
        name: "فلتر هواء محرك - فورد فوكس",
        price: "85.00",
        oldPrice: null,
        image: "/api/images/air-filter.png",
        category: "فلاتر",
        inStock: false,
        isNew: false,
        onSale: false,
      },
      {
        name: "شمعات احتراق (4 قطع) - هوندا أكورد",
        price: "120.00",
        oldPrice: null,
        image: "/api/images/spark-plugs.png",
        category: "محرك",
        inStock: true,
        isNew: true,
        onSale: false,
      },
      {
        name: "فحمات فرامل خلفية - مازدا 6",
        price: "180.00",
        oldPrice: null,
        image: "/api/images/brake-pads.png",
        category: "فرامل",
        inStock: true,
        isNew: false,
        onSale: false,
      },
      {
        name: "فلتر زيت + فلتر هواء - كيا سيراتو",
        price: "95.00",
        oldPrice: "130.00",
        image: "/api/images/oil-filter.png",
        category: "فلاتر",
        inStock: true,
        isNew: false,
        onSale: true,
      },
    ];

    initialProducts.forEach(product => {
      const id = randomUUID();
      this.products.set(id, { ...product, id });
    });
  }

  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = {
      ...insertProduct,
      id,
      inStock: insertProduct.inStock ?? true,
      oldPrice: insertProduct.oldPrice ?? null,
      isNew: insertProduct.isNew ?? null,
      onSale: insertProduct.onSale ?? null,
    };
    this.products.set(id, product);
    return product;
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = randomUUID();
    const order: Order = {
      ...insertOrder,
      id,
      status: 'pending',
      createdAt: new Date(),
    };
    this.orders.set(id, order);
    return order;
  }

  async getOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }
}

export const storage = new MemStorage();
