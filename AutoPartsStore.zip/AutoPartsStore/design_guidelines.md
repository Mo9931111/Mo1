# Design Guidelines: Auto Parts E-Commerce Store

## Design Approach
**Reference-Based Approach** - Drawing inspiration from successful e-commerce platforms (Shopify, Amazon) adapted for the automotive aftermarket industry with full Arabic/RTL support.

**Core Principles:**
- Trust and professionalism to build confidence in auto parts quality
- Clear product hierarchy with easy navigation between categories
- Mobile-first responsive design for on-the-go mechanics and car owners
- Rich product imagery to help users identify correct parts

---

## Color Palette

### Light Mode
- **Primary Brand:** 210 100% 25% (Deep automotive blue - professional, trustworthy)
- **Secondary:** 210 15% 95% (Light gray blue for backgrounds)
- **Accent:** 25 95% 50% (Orange-red for CTAs, sale badges, warnings)
- **Success:** 142 71% 45% (Green for in-stock indicators)
- **Text Primary:** 210 20% 15%
- **Text Secondary:** 210 10% 45%
- **Background:** 0 0% 100%
- **Surface:** 210 15% 98%

### Dark Mode
- **Primary Brand:** 210 90% 65%
- **Background:** 220 15% 10%
- **Surface:** 220 15% 15%
- **Text Primary:** 210 10% 95%
- **Text Secondary:** 210 10% 70%

---

## Typography

**Arabic-First Font System:**
- **Primary:** 'Tajawal', 'Cairo', sans-serif (Google Fonts CDN)
- **Secondary:** 'Inter', 'Roboto', sans-serif (for numbers/SKUs)

**Scale:**
- Hero Headline: text-5xl/text-6xl font-bold
- Section Headers: text-3xl/text-4xl font-bold
- Product Titles: text-xl font-semibold
- Body Text: text-base
- Small/Meta: text-sm text-gray-600

---

## Layout System

**RTL-First Grid:** Full RTL support with `dir="rtl"` on html element

**Spacing Primitives:** Consistent use of 2, 4, 6, 8, 12, 16, 20 units
- Component padding: p-4, p-6, p-8
- Section spacing: py-12, py-16, py-20
- Grid gaps: gap-4, gap-6, gap-8

**Containers:**
- Max width: max-w-7xl mx-auto
- Side padding: px-4 md:px-6 lg:px-8

---

## Component Library

### Navigation
- Sticky header with logo (right), category mega-menu, search bar, cart icon (left)
- Breadcrumbs on all product/category pages
- Mobile: Hamburger menu with slide-out drawer

### Product Cards
- Card layout with shadow-sm hover:shadow-md transition
- Product image (4:3 aspect ratio) with overlay badge for "جديد" or "تخفيض"
- Product name (2 lines max, truncate)
- Price (large, bold) with old price struck-through if on sale
- Stock status indicator (green dot + text)
- Quick "إضافة للسلة" button on hover/tap

### Product Grid
- Grid: grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6
- Responsive images with loading="lazy"

### Filters Sidebar
- Collapsible sections: حسب السيارة، حسب النوع، حسب السعر، حسب الماركة
- Checkboxes with product counts
- Range slider for price filter
- Mobile: Bottom sheet or drawer

### Shopping Cart
- Slide-out panel from left (RTL)
- Item list with thumbnail, name, quantity stepper, price
- Subtotal calculation
- Prominent "إتمام الطلب" button

### Product Detail Page
- Large image gallery (thumbnails + main image with zoom)
- Product title, SKU, rating stars
- Price with stock indicator
- Specifications table
- Quantity selector + "إضافة للسلة" button
- Related products carousel

### Forms
- Consistent input styling with focus:ring-2 focus:ring-primary
- Labels above inputs (RTL aligned)
- Form validation with clear error messages
- Large touch targets (min-h-12)

---

## Images

**Hero Section:**
Large hero image (1920x800px) showing organized auto parts warehouse or mechanic working on car. Overlay with gradient (from black/60% to transparent) for text readability.
- Headline overlay: "قطع غيار أصلية لجميع أنواع السيارات"
- Search bar prominent in hero for part lookup

**Product Images:**
High-quality photos on white/light gray background (800x600px minimum). Multiple angles for each product in detail pages.

**Category Banners:**
Contextual images for each category (محرك، فرامل، إضاءة، etc.) - 1200x400px banners

**Trust Badges:**
Icons for shipping, warranty, authentic parts - placed in footer and checkout

---

## Key Pages Layout

### Homepage
1. Hero with search
2. Featured Categories (4-6 cards with images)
3. Best Sellers grid (8-12 products)
4. Brands showcase (logo grid)
5. Why Choose Us (3-column features)
6. Recent Reviews
7. Newsletter signup
8. Footer (comprehensive links, contact, payment methods)

### Category/Shop Page
- Filters sidebar (right in RTL)
- Products grid with sorting dropdown
- Pagination at bottom
- Active filters display with clear buttons

### Product Detail
- 2-column layout: Image gallery (right) + Product info (left)
- Tabs for: المواصفات، التوافق مع السيارات، التقييمات
- Related products section

### Checkout
- Multi-step: سلة التسوق → معلومات التوصيل → الدفع
- Progress indicator
- Order summary sticky on desktop

---

## Responsive Breakpoints
- Mobile: < 768px (single column, bottom cart, simplified nav)
- Tablet: 768-1024px (2-3 columns)
- Desktop: > 1024px (4 columns, full filters)

---

## Performance & Accessibility
- Lazy load product images
- Proper ARIA labels for RTL navigation
- High contrast for text on images
- Keyboard navigation support
- Touch-friendly (48px minimum tap targets)